#include <iostream>
using namespace std;
#include <algorithm>
#include <cstdlib>
#include <iostream>
using namespace std;
#define WALL '*'
#define KOSTOCKA '-'
#define UP 'w'
#define DOWN 's'
#define LEFT 'a'
#define RIGHT 'd'
#define SOBACHKA '@'
int lines = 11, columns = 16, fruits = 1, didgameend = 0;
char inputboard[100][100]{
    "   *************", "         *     *", "****  *  ****  *",
    "*     *        *", "*  *******  ****", "*  *           *",
    "*  *  *  ****  *", "*  *  *  *     *", "*  *  *******  *",
    "*  *     *    - ", "*************   ",
};
char inplvl2[100][100]{
    "   *************", "   *           *", "*  *  *******  *",
    "*     *     *  *", "*  ****  *******", "*  *           *",
    "*  ****  ****  *", "*  *  *     *  *", "*  *  ****  ****",
    "*               ", "*************  -"};
char inplvl3[100][100]{
    "   *************", "   *  *     *  *", "*  *  *  ****  *",
    "*           *  *", "****  *  *  *  *", "*  *  *  *     *",
    "*  *  ****  ****", "*     *        *", "****  *  *  ****",
    "*     *  *      ", "*************  -"};
char inplvl4[100][100]{
"   *************",
"   *  *        *",
"*  *  ****  ****",
"*        *     *",
"****  ****  ****",
"*  *           *",
"*  *******  *  *",
"*           *  *",
"*******  *******",
"*               ",
"*************   "
};
bool cover[100][100];
int inpline= 0;
int inpcol= 0;
bool inside(int line, int col) {
  return 0 <= line && line < lines && 0 <= col && col < columns;
}
void movementprocess(char command) {
  int next_line = inpline, next_col = inpcol;
  if (command == UP) {
    if (inputboard[inpline - 1][inpcol] == '*') {
    } else if (inputboard[inpline + 1][inpcol] == '-') {
      switch (didgameend) {
      case 0: {
        didgameend = 2;
        break;
      };
      case 8: {
        didgameend = 3;
        break;
      };
      case 9: {
        didgameend = 4;
        break;
      }
      }
      --next_line;
    } else {
      --next_line;
    }
  } else if (command == DOWN) {
    if (inputboard[inpline + 1][inpcol] == '*') {
    } else if (inputboard[inpline + 1][inpcol] == '-') {
      switch (didgameend) {
      case 0: {
        didgameend = 2;
        break;
      };
      case 8: {
        didgameend = 3;
        break;
      };
      case 9: {
        didgameend = 4;
        break;
      }
      case 4: {
        cout << "\n\t- Y O U W O N ! -\n";
        cout
            << "\t                 *@%@@,@              @@@            \n\t    "
               "     "
               "      @.,#,,,,,@            @*,,*@/,@       \n\t               "
               "@,,,,,%@@,@,        (/.@@,,,,,%%      \n\t               "
               "@,**,@@(@@@*@@@@@@@@,@@@/@/,,,,@      \n\t             &@,,@#  "
               "(@%@@,,,,,,,,,,,,@   .@,,.@     \n\t                  @       "
               "@     "
               " @,,,,@              \n\t                @    @@@# @/     "
               "@,,,,&    "
               "          \n\t      @@((@@    @    @%@@ @.   (@&,,,,,,@        "
               "    "
               "\n\t      @@@@@@@@@@@@@@,,,,,*%.,,.*/*,,,,*,%&           \n\t  "
               "     "
               " @&(@@&,,,,@(.,,,,,,,@%@,,,,,**/*@            \n\t          "
               "@@@,,,,,,@,,,,,(@%%@,,(,*/*/@              \n\t               "
               "@@@@@@*%/&%%%@,,@@&/                  \n\t                    "
               ",#&@@&@.,&                       \n\t                  "
               "@(@((&(,.@(  "
               "                    \n\t                  @#@*             "
               "\n\n";

        didgameend = 1;
        break;
      }
      }
      ++next_line;
    } else {
      ++next_line;
    }
  } else if (command == LEFT) {
    if (inputboard[inpline][inpcol - 1] == '*') {
    } else if (inputboard[inpline + 1][inpcol] == '-') {
      switch (didgameend) {
      case 0: {
        didgameend = 2;
        break;
      };
      case 8: {
        didgameend = 3;
        break;
      };
      case 9: {
        didgameend = 4;
        break;
      }
      }
      --next_col;
    } else {
      --next_col;
    }
  } else if (command == RIGHT) {
    if (inputboard[inpline][inpcol + 1] == '*') {
    } else if (inputboard[inpline + 1][inpcol] == '-') {
      switch (didgameend) {
      case 0: {
        didgameend = 2;
        break;
      };
      case 8: {
        didgameend = 3;
        break;
      };
      case 9: {
        didgameend = 4;
        break;
      }
      }
      ++next_col;
    } else {
      ++next_col;
    }
  }
  if (!inside(next_line, next_col))
    return;
  if (!cover[inpline][inpcol])
    inputboard[inpline][inpcol] = ' ';
  else
    inputboard[inpline][inpcol] = inputboard[inpline][inpcol];
  inpline = next_line;
  inpcol = next_col;
  inputboard[inpline][inpcol] = SOBACHKA;
}
void coutboard() {
  for (int line = 0; line < lines; ++line) {
    for (int col = 0; col < columns; ++col)
      cout << inputboard[line][col];
    cout << endl;
  }
}
void gamestart() {
  inpline = inpcol = 0;
  didgameend = 0;
  inputboard[inpline][inpcol] = SOBACHKA;
}
int main() {
  char choice;
  cout << "\t                 *@%@@,@              @@@            \n\t         "
          "      @.,#,,,,,@            @*,,*@/,@       \n\t               "
          "@,,,,,%@@,@,        (/.@@,,,,,%%      \n\t               "
          "@,**,@@(@@@*@@@@@@@@,@@@/@/,,,,@      \n\t             &@,,@#  "
          "(@%@@,,,,,,,,,,,,@   .@,,.@     \n\t                  @       @     "
          " @,,,,@              \n\t                @    @@@# @/     @,,,,&    "
          "          \n\t      @@((@@    @    @%@@ @.   (@&,,,,,,@            "
          "\n\t      @@@@@@@@@@@@@@,,,,,*%.,,.*/*,,,,*,%&           \n\t       "
          " @&(@@&,,,,@(.,,,,,,,@%@,,,,,**/*@            \n\t          "
          "@@@,,,,,,@,,,,,(@%%@,,(,*/*/@              \n\t               "
          "@@@@@@*%/&%%%@,,@@&/                  \n\t                    "
          ",#&@@&@.,&                       \n\t                  @(@((&(,.@(  "
          "                    \n\t                  @#@*             \n\n";
  cout << "\t\t- S O B A C H K A! -\t- S T A R T  G A M E -\t \n\n";
  cin >> choice;
  gamestart();
  while (didgameend != 1) {
    coutboard();
    char command;
    cout << "Input command: ";
    cin >> command;
    movementprocess(command);
    if (didgameend == 2) {
      inpline = inpcol = 0;
      didgameend = 8;
      for (int i = 0; i < 100; i++) {
        for (int j = 0; j < 100; j++) {
          inputboard[i][j] = inplvl2[i][j];
        }
      }
    }
    if (didgameend == 3) {
      inpline = inpcol = 0;
      didgameend = 9;
      for (int i = 0; i < 100; i++) {
        for (int j = 0; j < 100; j++) {
          inputboard[i][j] = inplvl3[i][j];
        }
      }
    }
    inputboard[inpline][inpcol] = SOBACHKA;
  }
  return 0;
}